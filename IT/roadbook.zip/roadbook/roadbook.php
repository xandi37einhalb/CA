<?php

$_stPdffile = 'in.pdf';
require_once('fpdf.php');
require_once('fpdi.php');
$pdf = new FPDI();
$pdf->AddPage('P');
$pdf->setSourceFile($_stPdffile);
$tplIdx = $pdf->importPage(1);
$pdf->useTemplate($tplIdx, 0, 0, 0, 0, true);
$pdf->AddFont('CompatilFactLTPro-Bd','B','CompatilFactLTPro-Bd.php');
$pdf->AddFont('CompatilFactLTPro-BdIt','B','CompatilFactLTPro-BdIt.php');
$pdf->AddFont('CompatilFactLTPro-It','','CompatilFactLTPro-It.php');
$pdf->AddFont('CompatilFactLTPro-Rg','','CompatilFactLTPro-Rg.php');
$pdf->AddFont('HIND-BOLD','','HIND-BOLD.php');

$pdf->SetFont('HIND-BOLD', '', 12);
$pdf->SetTextColor(0,0,0);
$pdf->SetFillColor(255, 255, 255);

$logofile = 'CA_logo.png';
$sourcefile = 'source.txt';

$source = fopen($sourcefile, "r");
$jsonsource = fread($source, filesize($sourcefile));
fclose($source);
$json = json_decode($jsonsource);

$format = $json->format;
$infobox = $json->infobox;
$waypoints = $json->waypoints;
$length = 1;
if (isset($json->distanceNum)) {
	if (is_numeric($json->distanceNum)) {
		$length = $json->distanceNum;
	}
}

$offsetTop = $format->offsetTop;
$offsetLeft = $format->offsetLeft;
$width = $format->width;
$tabInfobox = $format->tabInfobox;


$pdf->Rect(($offsetLeft-2), ($offsetTop-2), 160, 30, 'F');
$pdf->SetDrawColor(200, 200, 200);
$pdf->Rect($offsetLeft, $offsetTop, $width, 10);
$pdf->SetDrawColor(0, 0, 0);

$count = 0;
foreach ($infobox as $key => $val) {
	if (trim($val)) {
		$pdf->Image($key . '.png', ($offsetLeft + $count*$tabInfobox), ($offsetTop + 2), 6);
		$pdf->SetXY($offsetLeft + $count*$tabInfobox + 8, ($offsetTop + 2.5));
		$pdf->Cell(20, 5, $val, 0, 0, 'L', 1);
		$count++;
	}
}

$pdf->SetFillColor(255, 255, 255);
$pdf->SetXY($offsetLeft, ($offsetTop + 13));
$pdf->SetFont('CompatilFactLTPro-Rg', '', 9);
$pdf->MultiCell($width, 5, utf8_decode($json->description), 0, 'L', 1);

foreach ($waypoints as $dist => $type) {
	if (is_numeric($dist)) {
		$offsetX = $width/$length*$dist;
		$pdf->Image($type . '.png', ($offsetLeft + $offsetX), ($offsetTop+30), 5);
	}
}


#$pdf->SetXY(26, 75);



#$pdf->Image($foodicon, 95, 100, 5);
#$pdf->Image($steepicon, 55, 100, 5);
#$pdf->Image($dangericon, 115, 100, 5);


#$objImage = fopen($_stImagefile, 'w');
#fwrite($objImage, $_aFiles['image']);
#fclose($objImage);
#$_iImageWidth = '';
#$_iImageHeight = '';
#if ($_aFiles['imageWidth']) $_iImageWidth = $_aFiles['imageWidth'];
#if ($_aFiles['imageHeight']) $_iImageHeight = $_aFiles['imageHeight'];
                                                
$pdf->Image($logofile, ($offsetLeft + 46.5), ($offsetTop-32), 27, '', '', 'https://cycling-adventures.org');
                                                
$pdfModfile = 'out.pdf';
$pdf->Output($pdfModfile, 'F');



?>