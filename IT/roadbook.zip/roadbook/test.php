<?php
require_once('fpdf.php');
require_once('fpdi.php');
$pdf = new FPDI();
$pdf->AddPage('L');
$pdf->setSourceFile('testout.pdf');
$tplIdx = $pdf->importPage(1);
$pdf->useTemplate($tplIdx, 0, 0, 0, 0, true);
$pdf->SetTextColor(0,0,0);
$pdf->SetXY(100, 100);
$pdf->SetFont('Arial', 'B', 16);
$pdf->Write(0, 'gift code');
$pdf->Output('gift_coupon_generated.pdf', 'F');



?>
